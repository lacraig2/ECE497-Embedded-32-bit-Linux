// A really useless program, but a program nevertheless

int main(int argc, char *argv[]){

   return 0;
}
