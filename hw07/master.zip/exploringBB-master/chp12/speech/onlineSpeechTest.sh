#!/bin/bash
mplayer -ao alsa:device=hw=5 "http://translate.google.com/translate_tts?tl=en&q=Hello%20from%20the%20BeagleBone%20Black"
